<?php

namespace WebManagementBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class WebManagementBundle extends Bundle
{
}
