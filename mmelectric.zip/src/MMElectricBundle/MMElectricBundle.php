<?php

namespace MMElectricBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MMElectricBundle extends Bundle
{
}
