$(document).ready(function(){
	$('#id_items_x_page').change(function(){
		var selected = $(this).val();
		window.location.href = selected;		
	});
	
});